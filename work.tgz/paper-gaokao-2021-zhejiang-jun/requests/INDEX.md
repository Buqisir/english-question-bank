# paper-gaokao-2021-zhejiang-jun · rev-27934707-8072-4b03-8694-0463e7aba2ee

合入结果见 `../ready/INDEX.md`。

| 请求 | 讲评文件 | 题号 | 草稿路径 |
| --- | --- | --- | --- |
| reading-a.request.json | analysis-reading-a.json | 21–23 | `/private/tmp/eqb-lecture/paper-gaokao-2021-zhejiang-jun/drafts/paper-gaokao-2021-zhejiang-jun__27934707__reading-a.json` |
| reading-b.request.json | analysis-reading-b.json | 24–27 | `/private/tmp/eqb-lecture/paper-gaokao-2021-zhejiang-jun/drafts/paper-gaokao-2021-zhejiang-jun__27934707__reading-b.json` |
| reading-c.request.json | analysis-reading-c.json | 28–30 | `/private/tmp/eqb-lecture/paper-gaokao-2021-zhejiang-jun/drafts/paper-gaokao-2021-zhejiang-jun__27934707__reading-c.json` |
| seven.request.json | analysis-seven.json | 31–35 | `/private/tmp/eqb-lecture/paper-gaokao-2021-zhejiang-jun/drafts/paper-gaokao-2021-zhejiang-jun__27934707__seven.json` |
| cloze.request.json | analysis-cloze.json | 36–55 | `/private/tmp/eqb-lecture/paper-gaokao-2021-zhejiang-jun/drafts/paper-gaokao-2021-zhejiang-jun__27934707__cloze.json` |
| grammar.request.json | analysis-grammar.json | 56–65 | `/private/tmp/eqb-lecture/paper-gaokao-2021-zhejiang-jun/drafts/paper-gaokao-2021-zhejiang-jun__27934707__grammar.json` |
| application.request.json | analysis-application.json | 写作任务 | `/private/tmp/eqb-lecture/paper-gaokao-2021-zhejiang-jun/drafts/paper-gaokao-2021-zhejiang-jun__27934707__application.json` |
| continuation.request.json | analysis-continuation.json | 写作任务 | `/private/tmp/eqb-lecture/paper-gaokao-2021-zhejiang-jun/drafts/paper-gaokao-2021-zhejiang-jun__27934707__continuation.json` |
| listening-unit.request.json | analysis-listening.json | 1–20 | `/private/tmp/eqb-lecture/paper-gaokao-2021-zhejiang-jun/drafts/paper-gaokao-2021-zhejiang-jun__27934707__listening-unit.json` |

