# paper-mock-zhejiang-jiangzhewan-2024-10 · rev-61447960-02d1-4db1-9b7c-f4cfc5cbc959

合入结果见 `../ready/INDEX.md`。

| 请求 | 讲评文件 | 题号 | 草稿路径 |
| --- | --- | --- | --- |
| reading-a.request.json | analysis-reading-a.json | 21–23 | `/private/tmp/eqb-lecture/paper-mock-zhejiang-jiangzhewan-2024-10/drafts/paper-mock-zhejiang-jiangzhewan-2024-10__61447960__reading-a.json` |
| reading-b.request.json | analysis-reading-b.json | 24–27 | `/private/tmp/eqb-lecture/paper-mock-zhejiang-jiangzhewan-2024-10/drafts/paper-mock-zhejiang-jiangzhewan-2024-10__61447960__reading-b.json` |
| reading-c.request.json | analysis-reading-c.json | 28–31 | `/private/tmp/eqb-lecture/paper-mock-zhejiang-jiangzhewan-2024-10/drafts/paper-mock-zhejiang-jiangzhewan-2024-10__61447960__reading-c.json` |
| reading-d.request.json | analysis-reading-d.json | 32–35 | `/private/tmp/eqb-lecture/paper-mock-zhejiang-jiangzhewan-2024-10/drafts/paper-mock-zhejiang-jiangzhewan-2024-10__61447960__reading-d.json` |
| seven.request.json | analysis-seven.json | 36–40 | `/private/tmp/eqb-lecture/paper-mock-zhejiang-jiangzhewan-2024-10/drafts/paper-mock-zhejiang-jiangzhewan-2024-10__61447960__seven.json` |
| cloze.request.json | analysis-cloze.json | 41–55 | `/private/tmp/eqb-lecture/paper-mock-zhejiang-jiangzhewan-2024-10/drafts/paper-mock-zhejiang-jiangzhewan-2024-10__61447960__cloze.json` |
| grammar.request.json | analysis-grammar.json | 56–65 | `/private/tmp/eqb-lecture/paper-mock-zhejiang-jiangzhewan-2024-10/drafts/paper-mock-zhejiang-jiangzhewan-2024-10__61447960__grammar.json` |
| application.request.json | analysis-application.json | 写作任务 | `/private/tmp/eqb-lecture/paper-mock-zhejiang-jiangzhewan-2024-10/drafts/paper-mock-zhejiang-jiangzhewan-2024-10__61447960__application.json` |
| continuation.request.json | analysis-continuation.json | 写作任务 | `/private/tmp/eqb-lecture/paper-mock-zhejiang-jiangzhewan-2024-10/drafts/paper-mock-zhejiang-jiangzhewan-2024-10__61447960__continuation.json` |
| listening-unit.request.json | analysis-listening.json | 1–20 | `/private/tmp/eqb-lecture/paper-mock-zhejiang-jiangzhewan-2024-10/drafts/paper-mock-zhejiang-jiangzhewan-2024-10__61447960__listening-unit.json` |

