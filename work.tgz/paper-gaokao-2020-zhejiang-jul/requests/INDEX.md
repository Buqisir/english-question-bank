# paper-gaokao-2020-zhejiang-jul · rev-fc282d83-abab-4530-95a1-4781c507e036

合入结果见 `../ready/INDEX.md`。

| 请求 | 讲评文件 | 题号 | 草稿路径 |
| --- | --- | --- | --- |
| reading-a.request.json | analysis-reading-a.json | 21–24 | `/private/tmp/eqb-lecture/paper-gaokao-2020-zhejiang-jul/drafts/paper-gaokao-2020-zhejiang-jul__fc282d83__reading-a.json` |
| reading-b.request.json | analysis-reading-b.json | 25–27 | `/private/tmp/eqb-lecture/paper-gaokao-2020-zhejiang-jul/drafts/paper-gaokao-2020-zhejiang-jul__fc282d83__reading-b.json` |
| reading-c.request.json | analysis-reading-c.json | 28–30 | `/private/tmp/eqb-lecture/paper-gaokao-2020-zhejiang-jul/drafts/paper-gaokao-2020-zhejiang-jul__fc282d83__reading-c.json` |
| seven.request.json | analysis-seven.json | 31–35 | `/private/tmp/eqb-lecture/paper-gaokao-2020-zhejiang-jul/drafts/paper-gaokao-2020-zhejiang-jul__fc282d83__seven.json` |
| cloze.request.json | analysis-cloze.json | 36–55 | `/private/tmp/eqb-lecture/paper-gaokao-2020-zhejiang-jul/drafts/paper-gaokao-2020-zhejiang-jul__fc282d83__cloze.json` |
| grammar.request.json | analysis-grammar.json | 56–65 | `/private/tmp/eqb-lecture/paper-gaokao-2020-zhejiang-jul/drafts/paper-gaokao-2020-zhejiang-jul__fc282d83__grammar.json` |
| application.request.json | analysis-application.json | 写作任务 | `/private/tmp/eqb-lecture/paper-gaokao-2020-zhejiang-jul/drafts/paper-gaokao-2020-zhejiang-jul__fc282d83__application.json` |
| continuation.request.json | analysis-continuation.json | 写作任务 | `/private/tmp/eqb-lecture/paper-gaokao-2020-zhejiang-jul/drafts/paper-gaokao-2020-zhejiang-jul__fc282d83__continuation.json` |
| listening-unit.request.json | analysis-listening.json | 1–20 | `/private/tmp/eqb-lecture/paper-gaokao-2020-zhejiang-jul/drafts/paper-gaokao-2020-zhejiang-jul__fc282d83__listening-unit.json` |

