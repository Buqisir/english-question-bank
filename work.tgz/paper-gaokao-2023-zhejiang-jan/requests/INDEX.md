# paper-gaokao-2023-zhejiang-jan · rev-2540064f-957b-4d61-b451-4e109d3cc1b9

合入结果见 `../ready/INDEX.md`。

| 请求 | 讲评文件 | 题号 | 草稿路径 |
| --- | --- | --- | --- |
| reading-a.request.json | analysis-reading-a.json | 21–23 | `/private/tmp/eqb-lecture/paper-gaokao-2023-zhejiang-jan/drafts/paper-gaokao-2023-zhejiang-jan__2540064f__reading-a.json` |
| reading-b.request.json | analysis-reading-b.json | 24–27 | `/private/tmp/eqb-lecture/paper-gaokao-2023-zhejiang-jan/drafts/paper-gaokao-2023-zhejiang-jan__2540064f__reading-b.json` |
| reading-c.request.json | analysis-reading-c.json | 28–31 | `/private/tmp/eqb-lecture/paper-gaokao-2023-zhejiang-jan/drafts/paper-gaokao-2023-zhejiang-jan__2540064f__reading-c.json` |
| reading-d.request.json | analysis-reading-d.json | 32–35 | `/private/tmp/eqb-lecture/paper-gaokao-2023-zhejiang-jan/drafts/paper-gaokao-2023-zhejiang-jan__2540064f__reading-d.json` |
| seven.request.json | analysis-seven.json | 36–40 | `/private/tmp/eqb-lecture/paper-gaokao-2023-zhejiang-jan/drafts/paper-gaokao-2023-zhejiang-jan__2540064f__seven.json` |
| cloze.request.json | analysis-cloze.json | 41–55 | `/private/tmp/eqb-lecture/paper-gaokao-2023-zhejiang-jan/drafts/paper-gaokao-2023-zhejiang-jan__2540064f__cloze.json` |
| grammar.request.json | analysis-grammar.json | 56–65 | `/private/tmp/eqb-lecture/paper-gaokao-2023-zhejiang-jan/drafts/paper-gaokao-2023-zhejiang-jan__2540064f__grammar.json` |
| application.request.json | analysis-application.json | 写作任务 | `/private/tmp/eqb-lecture/paper-gaokao-2023-zhejiang-jan/drafts/paper-gaokao-2023-zhejiang-jan__2540064f__application.json` |
| continuation.request.json | analysis-continuation.json | 写作任务 | `/private/tmp/eqb-lecture/paper-gaokao-2023-zhejiang-jan/drafts/paper-gaokao-2023-zhejiang-jan__2540064f__continuation.json` |
| listening-unit.request.json | analysis-listening.json | 1–20 | `/private/tmp/eqb-lecture/paper-gaokao-2023-zhejiang-jan/drafts/paper-gaokao-2023-zhejiang-jan__2540064f__listening-unit.json` |

