# paper-gaokao-2020-zhejiang-jan · rev-a3d518b5-de9d-4ced-9de8-b996cca0c319

合入结果见 `../ready/INDEX.md`。

| 请求 | 讲评文件 | 题号 | 草稿路径 |
| --- | --- | --- | --- |
| reading-a.request.json | analysis-reading-a.json | 21–23 | `/private/tmp/eqb-lecture/paper-gaokao-2020-zhejiang-jan/drafts/paper-gaokao-2020-zhejiang-jan__a3d518b5__reading-a.json` |
| reading-b.request.json | analysis-reading-b.json | 24–26 | `/private/tmp/eqb-lecture/paper-gaokao-2020-zhejiang-jan/drafts/paper-gaokao-2020-zhejiang-jan__a3d518b5__reading-b.json` |
| reading-c.request.json | analysis-reading-c.json | 27–30 | `/private/tmp/eqb-lecture/paper-gaokao-2020-zhejiang-jan/drafts/paper-gaokao-2020-zhejiang-jan__a3d518b5__reading-c.json` |
| seven.request.json | analysis-seven.json | 31–35 | `/private/tmp/eqb-lecture/paper-gaokao-2020-zhejiang-jan/drafts/paper-gaokao-2020-zhejiang-jan__a3d518b5__seven.json` |
| cloze.request.json | analysis-cloze.json | 36–55 | `/private/tmp/eqb-lecture/paper-gaokao-2020-zhejiang-jan/drafts/paper-gaokao-2020-zhejiang-jan__a3d518b5__cloze.json` |
| grammar.request.json | analysis-grammar.json | 56–65 | `/private/tmp/eqb-lecture/paper-gaokao-2020-zhejiang-jan/drafts/paper-gaokao-2020-zhejiang-jan__a3d518b5__grammar.json` |
| application.request.json | analysis-application.json | 写作任务 | `/private/tmp/eqb-lecture/paper-gaokao-2020-zhejiang-jan/drafts/paper-gaokao-2020-zhejiang-jan__a3d518b5__application.json` |
| continuation.request.json | analysis-continuation.json | 写作任务 | `/private/tmp/eqb-lecture/paper-gaokao-2020-zhejiang-jan/drafts/paper-gaokao-2020-zhejiang-jan__a3d518b5__continuation.json` |
| listening-unit.request.json | analysis-listening.json | 1–20 | `/private/tmp/eqb-lecture/paper-gaokao-2020-zhejiang-jan/drafts/paper-gaokao-2020-zhejiang-jan__a3d518b5__listening-unit.json` |

