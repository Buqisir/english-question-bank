# paper-mock-shandong-weifang-2025-m1 · rev-2961dc8d-c161-45b8-bb9b-6e0a0e4c30d4

合入结果见 `../ready/INDEX.md`。

| 请求 | 讲评文件 | 题号 | 草稿路径 |
| --- | --- | --- | --- |
| reading-a.request.json | analysis-reading-a.json | 21–23 | `/tmp/eqb-lecture/paper-mock-shandong-weifang-2025-m1/drafts/paper-mock-shandong-weifang-2025-m1__2961dc8d__reading-a.json` |
| reading-b.request.json | analysis-reading-b.json | 24–27 | `/tmp/eqb-lecture/paper-mock-shandong-weifang-2025-m1/drafts/paper-mock-shandong-weifang-2025-m1__2961dc8d__reading-b.json` |
| reading-c.request.json | analysis-reading-c.json | 28–31 | `/tmp/eqb-lecture/paper-mock-shandong-weifang-2025-m1/drafts/paper-mock-shandong-weifang-2025-m1__2961dc8d__reading-c.json` |
| reading-d.request.json | analysis-reading-d.json | 32–35 | `/tmp/eqb-lecture/paper-mock-shandong-weifang-2025-m1/drafts/paper-mock-shandong-weifang-2025-m1__2961dc8d__reading-d.json` |
| seven.request.json | analysis-seven.json | 36–40 | `/tmp/eqb-lecture/paper-mock-shandong-weifang-2025-m1/drafts/paper-mock-shandong-weifang-2025-m1__2961dc8d__seven.json` |
| cloze.request.json | analysis-cloze.json | 41–55 | `/tmp/eqb-lecture/paper-mock-shandong-weifang-2025-m1/drafts/paper-mock-shandong-weifang-2025-m1__2961dc8d__cloze.json` |
| grammar.request.json | analysis-grammar.json | 56–65 | `/tmp/eqb-lecture/paper-mock-shandong-weifang-2025-m1/drafts/paper-mock-shandong-weifang-2025-m1__2961dc8d__grammar.json` |
| application.request.json | analysis-application.json | 写作任务 | `/tmp/eqb-lecture/paper-mock-shandong-weifang-2025-m1/drafts/paper-mock-shandong-weifang-2025-m1__2961dc8d__application.json` |
| continuation.request.json | analysis-continuation.json | 写作任务 | `/tmp/eqb-lecture/paper-mock-shandong-weifang-2025-m1/drafts/paper-mock-shandong-weifang-2025-m1__2961dc8d__continuation.json` |
| listening-unit.request.json | analysis-listening.json | 1–20 | `/tmp/eqb-lecture/paper-mock-shandong-weifang-2025-m1/drafts/paper-mock-shandong-weifang-2025-m1__2961dc8d__listening-unit.json` |

