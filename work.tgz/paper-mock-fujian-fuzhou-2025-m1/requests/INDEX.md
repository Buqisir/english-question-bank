# paper-mock-fujian-fuzhou-2025-m1 · rev-c64f8981-5d2a-4993-909f-58f2cfeecc74

合入结果见 `../ready/INDEX.md`。

| 请求 | 讲评文件 | 题号 | 草稿路径 |
| --- | --- | --- | --- |
| reading-a.request.json | analysis-reading-a.json | 21–23 | `/tmp/eqb-lecture/paper-mock-fujian-fuzhou-2025-m1/drafts/paper-mock-fujian-fuzhou-2025-m1__c64f8981__reading-a.json` |
| reading-b.request.json | analysis-reading-b.json | 24–27 | `/tmp/eqb-lecture/paper-mock-fujian-fuzhou-2025-m1/drafts/paper-mock-fujian-fuzhou-2025-m1__c64f8981__reading-b.json` |
| reading-c.request.json | analysis-reading-c.json | 28–31 | `/tmp/eqb-lecture/paper-mock-fujian-fuzhou-2025-m1/drafts/paper-mock-fujian-fuzhou-2025-m1__c64f8981__reading-c.json` |
| reading-d.request.json | analysis-reading-d.json | 32–35 | `/tmp/eqb-lecture/paper-mock-fujian-fuzhou-2025-m1/drafts/paper-mock-fujian-fuzhou-2025-m1__c64f8981__reading-d.json` |
| seven.request.json | analysis-seven.json | 36–40 | `/tmp/eqb-lecture/paper-mock-fujian-fuzhou-2025-m1/drafts/paper-mock-fujian-fuzhou-2025-m1__c64f8981__seven.json` |
| cloze.request.json | analysis-cloze.json | 41–55 | `/tmp/eqb-lecture/paper-mock-fujian-fuzhou-2025-m1/drafts/paper-mock-fujian-fuzhou-2025-m1__c64f8981__cloze.json` |
| grammar.request.json | analysis-grammar.json | 56–65 | `/tmp/eqb-lecture/paper-mock-fujian-fuzhou-2025-m1/drafts/paper-mock-fujian-fuzhou-2025-m1__c64f8981__grammar.json` |
| application.request.json | analysis-application.json | 写作任务 | `/tmp/eqb-lecture/paper-mock-fujian-fuzhou-2025-m1/drafts/paper-mock-fujian-fuzhou-2025-m1__c64f8981__application.json` |
| continuation.request.json | analysis-continuation.json | 写作任务 | `/tmp/eqb-lecture/paper-mock-fujian-fuzhou-2025-m1/drafts/paper-mock-fujian-fuzhou-2025-m1__c64f8981__continuation.json` |
| listening-unit.request.json | analysis-listening.json | 1–20 | `/tmp/eqb-lecture/paper-mock-fujian-fuzhou-2025-m1/drafts/paper-mock-fujian-fuzhou-2025-m1__c64f8981__listening-unit.json` |

